/* hw3b.js */
window.onload = function() {



var fms=document.forms[0];
var ty=fms.elements[1].value;
//alert(ty);

/////  1  ///////
/////section character count for bio /////

bio.addEventListener("keyup", countdown, false);
var count=0;
var wordcount=0; //init
//remember to change to 140 from 14

function countdown (e){
  var words1=document.getElementById("bio").value; //get input
  var wordcount=words1.length; //handling paste of long text
  //alert (wordcount);

   if (count===140 || wordcount>140) {
     document.getElementById("charsLeft").innerText='0';
     alert("Really. You cannot type more than 140 chars!!! Not even with pasting!!");
     var charlength = words1.substring(0, 140);

     document.getElementById("bio").value = charlength;
     document.getElementById("bio").maxLength = "140";
     bio.removeEventListener("keyup", countdown, false);
     return;
   }
   else {
    count++;
    document.getElementById("charsLeft").innerText=140-wordcount;
   }
}


/////  2  ///////
/////section password matching and min chars /////


pwd2.addEventListener("change", pwcount, false);
function pwcount (e){
  pword1=document.getElementById("pwd1").value; 
  pword2=document.getElementById("pwd2").value; 
  if (pword1!=pword2){
    alert("pword must match");
    hw4Form.action=" ";
  }
  else if (pword1.length<8){
    alert("pword must be at least 8 chars long");
     hw4Form.action=" ";
  } 
  else {
     hw4Form.action="http://morpheus.dce.harvard.edu/cgi-bin/echo.cgi";
  }
}


/////  3  ///////
/////section show hide form element /////

document.getElementById("twit").addEventListener("click", chbox);

function chbox (e){
var showtwit=document.getElementById("twit");
	if (showtwit.checked==false){
		document.getElementById("twitter").style.visibility="hidden";
	}
	else if (showtwit.checked == true){
		document.getElementById("twitter").style.visibility="visible";
	}
}

/////  4  ///////
/////section to add selects /////



var colors=[['---',], ['red heels', 'blue ballet', 'black flats', 'brown loafers'], ['Prada clutch', 'Cole Haan satchel', 'Coach shoulder', 'Furla evening'], ['wool', 'cashmere', 'trench'], ['Italian kid', 'driving', 'mittens']];

var sel = document.getElementById("firstSelect");
document.getElementById("firstSelect").addEventListener("change", chgSel);
var counter=1;


function chgSel() {
         
var sel1 = document.createElement("select");
sel1.setAttribute("id", "secondSelect" + counter);
             //alert(sel1.id);
var sel2 = document.getElementById("secondSelect" + (counter-1));
            //alert(sel2.id); //secondselect1
var parentDiv = sel2.parentNode;
parentDiv.replaceChild(sel1, sel2);
       
  var opts = sel.options[sel.selectedIndex].value;
   //alert (opts); ///yes
  var lenght1=colors[opts].length;
   for (var i = 0; i < lenght1; i++) {
     alert (colors [opts][i]);
        var opt = document.createElement('option');
        var txtNode = document.createTextNode(colors[opts][i]);
     
        opt.appendChild(txtNode);
        sel1.appendChild(opt);
       
    } 
counter++;

}  ///replace thing above secondSelect


}

