/* hw3b.js */
window.onload = function() {



var fms=document.forms[0];
var ty=fms.elements[1].value;
//alert(ty);



/////  4  ///////
/////section to add selects /////



var colors=[['---',], ['red heels', 'blue ballet', 'black flats', 
'brown loafers'], ['Prada clutch', 'Cole Haan satchel', 'Coach shoulder', 
'Furla evening'], ['wool', 'cashmere', 'trench'], ['Italian kid', 'driving', 'mittens']];

var sel = document.getElementById("firstSelect");
document.getElementById("firstSelect").addEventListener("change", chgSel);
var counter=1;


function chgSel() {
         
var sel1 = document.createElement("select");
sel1.setAttribute("id", "secondSelect" + counter);
             //alert(sel1.id);
var sel2 = document.getElementById("secondSelect" + (counter-1));
            //alert(sel2.id); //secondselect1
var parentDiv = sel2.parentNode;
parentDiv.replaceChild(sel1, sel2);
       
  var opts = sel.options[sel.selectedIndex].value;
   //alert (opts); ///yes
  var lenght1=colors[opts].length;
   for (var i = 0; i < lenght1; i++) {
     alert (colors [opts][i]);
        var opt = document.createElement('option');
        var txtNode = document.createTextNode(colors[opts][i]);
     
        opt.appendChild(txtNode);
        sel1.appendChild(opt);
       
    } 
counter++;

}  ///replace thing above secondSelect


}

